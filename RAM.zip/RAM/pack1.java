import mypack.B;
public class pack1 {
    public static void main(String[] args) {
        B b=new B();
        System.out.println(b.sum(2,3));
    }
}
