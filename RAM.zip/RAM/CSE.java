package dept;
public class CSE{
    public void subjects(){
        System.out.println("oops + dsa");
    }
}