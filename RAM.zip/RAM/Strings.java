import java.util.*;
public class Strings {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String s = sc.next();
        char ch= sc.next().charAt(0);
        System.out.println(s.indexOf(ch));
        // for(int i=0;i<s.length;i++){

        // }
        // String s2="rohit";
        // String s3="viRat";
        // String s=new String("ram");
        // System.out.println(s);
        // System.out.println(s1.equals(s2));
        // System.out.println(s1.equalsIgnoreCase(s3));
    }
}
