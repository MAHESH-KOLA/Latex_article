import java.util.*;
import java.lang.*;

class vehicle{
 	String Company, Model;
 	double Mileage, Fuel_Capacity,Displacement;
   vehicle(){
    System.out.println("vehicle class");
    }
 }
 
 class two_wheeler extends vehicle{
    String Front_Brake, Rear_Brake, Tyre_Type, Head_lamp;
    String[] User_Reviews = {"Super", "Good" };
 	void setDetails(){
 	
 	}
 	void getDetails(){
 	
 	}
 }
 
 class four_wheeler extends vehicle{
 	String Air_Conditioner, air_bags, Power_Steering,Rain_Sensing_wiper;
 	void setDetails(){
 	
 	}
 	void getDetails(){
 	
 	}
 }
 
 class vehicle1{
  public static void main(String args[]){
  
  }
 }
 
