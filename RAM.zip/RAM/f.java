package dept.faulty;
public class f{
    public void subjects(){
        System.out.println("faculty");
    }
}