import mypack.A;

class Main{
public static void main(String[] args) {
    A a= new A();
   // B b=new B();
    System.out.println(a.sub(2,3));
   // System.out.println(b.sub(2,3));

}
}