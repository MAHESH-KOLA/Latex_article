package s;
import java.util.*;
public class podcast{
     public void play(){
        Scanner sc= new Scanner(System.in);
        System.out.println("enter sound: ");
        String s=sc.next();
        System.out.println("play: "+s);
     }
}
