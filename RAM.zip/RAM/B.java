package pack;
public class B{
    public void m2(){
        System.out.println("class B");
    }
}
