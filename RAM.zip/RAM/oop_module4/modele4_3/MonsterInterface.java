package Monster;

public interface MonsterInterface {
	
	public void setName(String name);	
	public String attack();
	public void setAttack(String attack);
	
}
