package Monster;

public class FireMonster extends Monster {

	public FireMonster(String string) {
		super(string);
	}

	public String attack() {
		String attack = "Attack with fire!";
		return attack;
	}
}

