package Monster;

public class WaterMonster extends Monster {

	public WaterMonster(String string) {
		super(string);
	}

	public String attack() {
		String attack = "Attack with water!";
		return attack;
	}
}
