import java.util.*;
class Wrapper{
    public static void main(String[] args) {
        int a=10;
        Integer obj = new Integer(a);
        System.out.println(obj);
    }
}