package mypack;

public class Simple{
 public static void main(String args[]){
	System.out.println("welcome to package!");
	}
}
// compile: javac -d . Simple.java
// run: java mypack.Simple