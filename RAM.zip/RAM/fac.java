import dept.faulty.f;
class fac{
    public static void main(String[] args) {
        f ff=new f();
        //ECE e= new ECE();
        ff.subjects();
       // e.subjects();
    }
}