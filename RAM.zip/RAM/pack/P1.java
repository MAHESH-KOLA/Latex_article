package pack2;

public class P1{
    public void m1(){
    System.out.println("class A");
    }
}