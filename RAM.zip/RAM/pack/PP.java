import pack2.P1;
import pack2.P2;

public class PP {
    public static void main(String[] args) {
        pack2.P1 p1 = new  pack2.P1();
         pack2.P2  p2 = new  pack2.P2();

        p1.m1();
        p2.m2();
    }
}