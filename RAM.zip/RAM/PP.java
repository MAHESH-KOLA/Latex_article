import Maahi.P1;
import Maahi.P2;

public class PP {
    public static void main(String[] args) {
        P1 p1 = new  P1();
        P2  p2 = new  P2();

        p1.m1();
        p2.m2();
    }
}