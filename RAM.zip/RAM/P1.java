package Maahi;

public class P1{
    public void m1(){
    System.out.println("class P1");
    }
}