import dept.CSE;
import dept.ECE;

class departments{
    public static void main(String[] args) {
        CSE c=new CSE();
        ECE e= new ECE();
        c.subjects();
        e.subjects();
    }
}