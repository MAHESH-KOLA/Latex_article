package Maahi;

public class P2{
    public void m2(){
    System.out.println("class P2");
    }
}