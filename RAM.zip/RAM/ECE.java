package dept;
public class ECE{
    public void subjects(){
        System.out.println("dec + ss");
    }
}