package s;

public interface dolby{
    public void playDolby();
}