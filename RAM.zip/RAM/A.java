package pack;
public class A{
    public void m1(){
        System.out.println("class A");
    }
    public void m2(){
        System.out.println("class m2");
    }
}
