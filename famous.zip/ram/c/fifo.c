#include<stdio.h>
#include<stdlib.h>
int main()
{
	int n,h,x=0,cur,dis,i;
	printf("enter number of processors");
	scanf("%d",&n);
	int a[n];
	printf("enter head value");
	scanf("%d",&h);
	printf("enter processors");
	for( i=0;i<n;i++)
	{
		scanf("%d",&a[i]);
	}
	printf("sequence is:");
	for(i=0;i<n;i++)
	{
		cur=a[i];
		dis=abs(h-cur);
		x=x+dis;
		h=cur;
		printf("%d\n",a[i]);
	}
	printf("Total seek operations %d",x);
}