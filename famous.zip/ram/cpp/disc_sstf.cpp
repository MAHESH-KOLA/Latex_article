#include<bits/stdc++.h>
using namespace std;
int main(){
	int n;
	cout<<"enter n: "<<endl;
	cin>>n;
	int limit;
	cout<<"enter limit: "<<endl;
	cin>>limit;
	vector<int> v(n);
	vector<int> vis(n);
	for(int i=0;i<n;i++){
		cin>>v[i];
		vis[i]=0;
	} 
	
	int head;
	cout<<"enter head: "<<endl;
	cin>>head;
	int res=0;
	int k=0;
	while(k<n){
		int mini=limit, ind=-1;
		for(int i=0;i<n;i++){
			if(vis[i]==0){
				if(abs(head-v[i])<mini){
				mini=abs(head-v[i]);
				ind=i;
			}
		}
	}
			res+=abs(head-v[ind]);
			vis[ind]=1;
			head=v[ind];
			k++;
		}
	cout<<"res: "<<res;	
}
// 82 170 43 140 24 16 190
