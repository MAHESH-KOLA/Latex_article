#include<bits/stdc++.h>
using namespace std;

int main(){
	int n, inst;
	cout<<"enter no. of processes: ";
	cin>>n;
	cout<<"enter no. of instances: ";
	cin>>inst;
	int alloted[n][inst], max[n][inst];
	cout<<"alloted: "<<endl;
	for(int i=0;i<n;i++){
		for(int j=0;j<inst;j++){
			cin>>alloted[i][j];
		}
	}
	cout<<"max: "<<endl;
	for(int i=0;i<n;i++){
		for(int j=0;j<inst;j++){
			cin>>max[i][j];
		}
	}	
	
	cout<<"available resources: ";
	int available[inst];
	for(int i=0;i<inst;i++){
		cin>>available[i];
	}
	
	int required[n][inst];
	for(int i=0;i<n;i++){
		for(int j=0; j<inst; j++){
			required[i][j]=max[i][j]-alloted[i][j];
		}
	}
	cout<<"required: "<<endl;
		for(int i=0;i<n;i++){
		for(int j=0; j<inst; j++){
			cout<<required[i][j]<<" ";
		}
		cout<<endl;
	}
	
	vector<int> vis(n, 0);
	vector<int> res;
	int deadlock=0;
	for(int l=0;l<n;l++){
		int p=-1;
		for(int i=0;i<n;i++){
			if(vis[i]==0){
			int flag=1;
			for(int j=0;j<inst;j++){
				if(required[i][j]>available[j]){
					flag=0;
				}
			}
			if(flag==1){
			p=i;
			break;
			}
		}
	}
	if(p==-1){
		deadlock=1;
	}
	else{
		res.push_back(p);
		vis[p]=1;
		for(int s=0;s<inst;s++)
		  available[s]+=alloted[p][s];		
	}
}
cout<<"available: ";
for(int i=0;i<inst; i++) cout<<available[i]<<" ";

cout<<endl<<"execution sequence: ";
for(int i=0;i<n;i++) cout<<"P"<<res[i]<<" ";
}
/*
0 1 0 2 0 0 3 0 2 2 1 1 0 0 2
7 5 3 3 2 2 9 0 2 2 2 2 4 3 3
3 3 2
*/

