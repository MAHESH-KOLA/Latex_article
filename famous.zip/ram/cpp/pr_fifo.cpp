#include<bits/stdc++.h>
using namespace std;

int main(){
	int np,nf;
	cout<<"entre no. of pages: ";
	cin>>np;
	int pages[np];
	cout<<"enter pages: "<<endl;
	for(int i=0;i<np;i++) cin>>pages[i];
	cout<<"enter no. of frames: ";
	cin>>nf;

	int hits=0, faults=0;
	queue<int> frames;
	for(int i=0;i<np;i++){
		queue<int> q2;
		bool flag=false;
		while(!frames.empty()){
			if(pages[i]==frames.front()) flag=true;
			q2.push(frames.front());
			frames.pop();
		}
		if(flag) hits++;
		else{
			faults++;
			if(q2.size()==nf) q2.pop();
			q2.push(pages[i]);
		}
		frames=q2;
	}
	cout<<"hits: "<<hits<<endl;
	cout<<"faults: "<<faults<<endl;
	
	/* 
	1 2 3 4 1 2 5 1 2 3 4 5
	
*/
}
