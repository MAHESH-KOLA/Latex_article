#include<bits/stdc++.h>
using namespace std;

struct process{
	int at, bt, ct, tat, wt, ps;
};
int findmin(process p[], int n, int ct){
	int ind=-1, mini=INT_MAX;
	for(int i=0;i<n;i++){
		if(p[i].at<=ct){
			if(p[i].bt<mini and  p[i].ps==0){
				mini=p[i].bt;
				ind=i;
			}
		}
	}
	return ind;
}
int main(){
	int n;
	cout<<"entre no. of processes: ";
	cin>>n;
	process p[n];
	int temp[n];
	for(int i=0;i<n;i++){
		cout<<"enter arrival and burst time of process: "<<i+1<<endl;
		cin>>p[i].at>>p[i].bt;
		p[i].ps=0;
		temp[i]=p[i].bt;
	}
	int k=0,ct=0;
	while(k<n){
		int ind=findmin(p, n, ct);
		if(ind!=-1){
			p[ind].bt=p[ind].bt-1;
			if(p[ind].bt==0){
				ct++;
				p[ind].ct=ct;
				p[ind].ps=1;
				k=k+1;
			//	ct++;
			}
			else{
				ct++;
			}
		
		}
		else{
			ct++;
		}
	}
	cout<<endl <<"complete time: ";
	for(int i=0;i<n;i++) cout<<p[i].ct<<" ";
		cout<<endl <<"turn around time: ";
	for(int i=0;i<n;i++){
		p[i].tat=p[i].ct-p[i].at;
	 cout<<p[i].tat<<" ";
}
		cout<<endl <<"waiting time: ";
	for(int i=0;i<n;i++) cout<<p[i].tat- temp[i]<<" ";
}

