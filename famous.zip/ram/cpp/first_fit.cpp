#include<bits/stdc++.h>
using namespace std;

int main(){
	int no_b, no_p;
	cout<<"entre no, of blocks: ";
	cin>>no_b;
	cout<<"enter no. of processes: ";
	cin>>no_p;
	int blocks[no_b], process[no_p];
	for(int i=0;i<no_b; i++) cin>>blocks[i];
	for(int i=0;i<no_p; i++) cin>>process[i];
	vector<int> allocation(no_p,-1);
	vector<int> frag(no_b);
	for(int i=0;i<no_b;i++){
		frag[i]=blocks[i];
	}
	for(int i=0;i<no_p;i++){
		for(int j=0;j<no_b;j++){
			if(blocks[j]>=process[i]){
				allocation[i]=j+1;
				blocks[j]-=process[i];
				frag[j]-=process[i];
				break;
			}
		}
	}
	cout<<"internal fragmentation: "<<endl;
	int sum=0;
	for(int i=0;i<no_b; i++){
		cout<<frag[i]<<" ";
		sum+=frag[i];
	}
	cout<<endl<<"internal fragmentation: "<<sum<<endl;
	for(int i=0;i<no_p;i++) cout<<allocation[i]<<" ";
	/*
	100 500 200 300 600
212 417 112 426
*/
}
