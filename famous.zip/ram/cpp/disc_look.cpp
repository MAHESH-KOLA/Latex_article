#include<bits/stdc++.h>
using namespace std;
int main(){
	int n;
	cout<<"enter n: "<<endl;
	cin>>n;
	int limit;
	cout<<"enter limit: "<<endl;
	cin>>limit;
	vector<int> v(n);
	vector<int> vis(n);
	int mini=limit, maxi=0;
	for(int i=0;i<n;i++){
		cin>>v[i];
		mini=min(v[i], mini);
		maxi=max(v[i], maxi);
		vis[i]=0;
	} 
	
	int head;
	cout<<"enter head: "<<endl;
	cin>>head;
	int res=maxi-head;
	if(mini<head) res+=maxi-mini;
	
	cout<<"res: "<<res;	
}
// 82 170 43 140 24 16 190
