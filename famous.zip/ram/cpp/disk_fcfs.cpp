#include<bits/stdc++.h>
using namespace std;
int main(){
	int n;
	cout<<"enter n: "<<endl;
	cin>>n;
	int limit;
	cout<<"enter limit: "<<endl;
	cin>>limit;
	vector<int> v(n);
	for(int i=0;i<n;i++) cin>>v[i];
	
	int head;
	cout<<"enter head: "<<endl;
	cin>>head;
	int res=0;
	res+=abs(head-v[0]);
	for(int i=1;i<n;i++){
		res=res+abs(v[i]-v[i-1]);
	}
	cout<<"res: "<<res;	
}
