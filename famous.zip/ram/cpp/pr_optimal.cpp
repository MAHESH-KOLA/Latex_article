#include<bits/stdc++.h>
using namespace std;

int main(){
	int np,nf;
	cout<<"entre no. of pages: ";
	cin>>np;
	int pages[np];
	cout<<"enter pages: "<<endl;
	for(int i=0;i<np;i++) cin>>pages[i];
	cout<<"enter no. of frames: ";
	cin>>nf;

	int hits=0, faults=0;
	unordered_map<int, int> m;
	for(int i=0;i<np;i++){
		if(m.size()!=nf){
			if(m[pages[i]]==1) hits++;
			else{
				faults++;
				m[pages[i]]=1;
			}
		}
		else{
			if(m[pages[i]]==1){
				hits++;
			}
			else{
				unordered_map<int , int> temp;
				for(auto it: m){
					temp[it.first]=0;
				}
				int last=-1;
				for(int j=i+1;j<np;j++){
						if(m[pages[j]]==1){
							temp[pages[j]]=j;
							last=pages[j];
						}
				}
				int flag=0, t;
				for(auto it: temp){
					if(it.second==0){
						t=it.first;
						flag=1;
						break;
					}
				}
				if(flag==1){
					m[t]=pages[i];
				}
				else{
					m[last]=pages[i];
				}
				faults++;
			}
		}
		
	}
	cout<<"hits: "<<hits<<endl;
	cout<<"faults: "<<faults<<endl;
	
	/* 
	1 2 3 4 1 2 5 1 2 3 4 5
	
*/
}
