#include<bits/stdc++.h>
using namespace std;

int pageFaults(int N, int C, int pages[]){
        // code here
        list<int>ls;
        int ans=0;
        unordered_map<int,list<int>::iterator>mp;
        for(int i=0;i<N;i++){
            if(mp.find(pages[i])==mp.end()){
                ans++;
                if(ls.size()>=C){
                    mp.erase(ls.back());
                    ls.pop_back();
                }
                ls.push_front(pages[i]);
                mp[pages[i]]=ls.begin();
            }
            else{
                ls.erase(mp[pages[i]]);
                ls.push_front(pages[i]);
                mp[pages[i]]=ls.begin();
            }
        }
        return ans;
    }

int main(){
	int np,nf;
	cout<<"entre no. of pages: ";
	cin>>np;
	int pages[np];
	cout<<"enter pages: "<<endl;
	for(int i=0;i<np;i++) cin>>pages[i];
	cout<<"enter no. of frames: ";
	cin>>nf;
	int res=pageFaults(np, nf,  pages);
	cout<<res;


}
	
/*
	vector<int> frames;
	int hit=0, fault=0;
	int recent=-1;
	for(int i=0;i<np;i++){
		if(frames.size()!=nf){
			int flag=0;
			for(int j=0;j<frames.size();j++){
				if(frames[j]==pages[i]){
					flag=1;
					break;
				}
			}
			if(flag==1) hit++;
			else{
				fault++;
				frames.push_back(pages[i]);
				recent=i;
			}
		}
		else{
			int f=0;
			for(int j=0;j<nf;j++){
				if(frames[j]==pages[i]){
					f=1;
					break;
			}
		}
		if(f==1) hit++;
		else{
			fault++;
			frames[pages[recent]]=pages[i];
			recent=i;
		}
	}
	}
	cout<<"hits: "<<hit<<endl;
	cout<<"faults: "<<fault<<endl;
	*/
	/* 
	1 2 3 4 1 2 5 1 2 3 4 5
	
*/

