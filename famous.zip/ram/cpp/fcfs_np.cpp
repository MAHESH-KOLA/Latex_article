#include<bits/stdc++.h>
using namespace std;

struct process{
	int at, bt, ct, tat, wt, ps;
};
int findmin(process p[], int n, int ct){
	int ind=-1, mini=INT_MAX;
	for(int i=0;i<n;i++){
		if(p[i].at<=ct){
			if(p[i].at<mini and  p[i].ps==0){
				mini=p[i].at;
				ind=i;
			}
		}
	}
	return ind;
}
int main(){
	int n;
	cout<<"entre no. of processes: ";
	cin>>n;
	process p[n];
	for(int i=0;i<n;i++){
		cout<<"enter arrival and burst time of process: "<<i+1<<endl;
		cin>>p[i].at>>p[i].bt;
		p[i].ps=0;
	}
	int k=0,ct=0;
	while(k<n){
		int ind=findmin(p, n, ct);
		if(ind!=-1){
			p[ind].ct=ct+p[ind].bt;
			ct=p[ind].ct;
			k=k+1;
			p[ind].ps=1;
		}
		else{
			ct++;
		}
	}
	for(int i=0;i<n;i++) cout<<p[i].ct<<" ";
}
