#include<bits/stdc++.h>
using namespace std;

struct process{
	int at, bt, ct, tat, wt, rt;
};

int main(){
	int n;
	cin>>n;
	process v[n];
	int total_time=0;
	for(int i=0;i<n;i++){
		cin>>v[i].at>>v[i].bt;
		v[i].rt=v[i].bt;
		total_time+=v[i].bt;
	}
	int tq; cin>>tq;
	vector<int> vis(n,0);
	queue<int> q;
	int time=0;
	while(time<total_time){
		bool flag=false;
		int x=0;
		if(!q.empty()){
			x=q.front();
			q.pop();
			v[x].ct=time+min(tq, v[x].rt);
			time+=min(tq, v[x].rt);
			v[x].rt-=min(tq, v[x].rt);
			flag=true;
		}
		for(int i=0;i<n;i++){
			if(vis[i]==0 and v[i].at<=time){
				q.push(i);
				vis[i]=1;
			}
		}
		if(v[x].rt!=0 and flag) q.push(x);
	}

		for(int i=0;i<n;i++){
			cout<<v[i].at<<" "<<v[i].bt<<" "<<v[i].ct<<endl;
		}
}
